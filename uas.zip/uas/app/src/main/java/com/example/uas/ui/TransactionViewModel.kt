// TransactionViewModel.kt
package com.example.uas.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.uas.data.AppRepository
import com.example.uas.data.Budget
import com.example.uas.data.Transaction
import kotlinx.coroutines.launch

class TransactionViewModel(private val repository: AppRepository) : ViewModel() {

    val allTransactions = repository.allTransactions
    val allBudgets = repository.allBudgets

    fun insertTransaction(transaction: Transaction) {
        viewModelScope.launch {
            repository.insertTransaction(transaction)
        }
    }

    fun insertBudget(budget: Budget) {
        viewModelScope.launch {
            repository.insertBudget(budget)
        }
    }
}
