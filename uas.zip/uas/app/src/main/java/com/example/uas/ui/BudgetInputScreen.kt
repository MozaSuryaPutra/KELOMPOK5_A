// ui/BudgetInputScreen.kt
package com.example.uas.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.uas.data.Budget
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun BudgetInputScreen(onSave: (Budget) -> Unit) {
    var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") }
        )
        TextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Amount") }
        )
        Button(onClick = {
            scope.launch {
                val budget = Budget(
                    category = category,
                    amount = amount.toDoubleOrNull() ?: 0.0,
                    month = Calendar.getInstance().get(Calendar.MONTH) + 1,
                    year = Calendar.getInstance().get(Calendar.YEAR)
                )
                onSave(budget)
                Toast.makeText(context, "Budget Saved", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text("Save Budget")
        }
    }
}
