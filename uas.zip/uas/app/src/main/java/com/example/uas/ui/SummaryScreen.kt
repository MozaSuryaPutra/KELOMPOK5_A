package com.example.uas.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas.data.Transaction
import com.example.uas.data.TransactionType
import java.util.*

@Composable
fun SummaryScreen(
    transactions: List<Transaction>,
    onDeleteTransaction: (Transaction) -> Unit
) {
    val dailyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isToday(it.date) }
    val weeklyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isThisWeek(it.date) }
    val monthlyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isThisMonth(it.date) }

    val dailyIncome = transactions.filter { it.type == TransactionType.INCOME && isToday(it.date) }
    val weeklyIncome = transactions.filter { it.type == TransactionType.INCOME && isThisWeek(it.date) }
    val monthlyIncome = transactions.filter { it.type == TransactionType.INCOME && isThisMonth(it.date) }

    val dailyBudgets = transactions.filter { it.type == TransactionType.BUDGET && isToday(it.date) }
    val weeklyBudgets = transactions.filter { it.type == TransactionType.BUDGET && isThisWeek(it.date) }
    val monthlyBudgets = transactions.filter { it.type == TransactionType.BUDGET && isThisMonth(it.date) }

    val totalDailyIncome = dailyIncome.sumOf { it.amount }
    val totalWeeklyIncome = weeklyIncome.sumOf { it.amount }
    val totalMonthlyIncome = monthlyIncome.sumOf { it.amount }

    val totalDailyBudget = dailyBudgets.sumOf { it.amount }
    val totalWeeklyBudget = weeklyBudgets.sumOf { it.amount }
    val totalMonthlyBudget = monthlyBudgets.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScrollableSection("Daily Summary") {
                SummaryContent("Expenses", dailyExpenses, onDeleteTransaction)
                SummaryContent("Income", dailyIncome, totalDailyIncome, onDeleteTransaction)
                SummaryContent("Budgets", dailyBudgets, totalDailyBudget, onDeleteTransaction)
            }
        }

        item {
            DividerLine()
        }

        item {
            ScrollableSection("Weekly Summary") {
                SummaryContent("Expenses", weeklyExpenses, onDeleteTransaction)
                SummaryContent("Income", weeklyIncome, totalWeeklyIncome, onDeleteTransaction)
                SummaryContent("Budgets", weeklyBudgets, totalWeeklyBudget, onDeleteTransaction)
            }
        }

        item {
            DividerLine()
        }

        item {
            ScrollableSection("Monthly Summary") {
                SummaryContent("Expenses", monthlyExpenses, onDeleteTransaction)
                SummaryContent("Income", monthlyIncome, totalMonthlyIncome, onDeleteTransaction)
                SummaryContent("Budgets", monthlyBudgets, totalMonthlyBudget, onDeleteTransaction)

                Spacer(modifier = Modifier.height(16.dp))

            }
        }
    }
}

@Composable
fun ScrollableSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.background(Color.LightGray).padding(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))
        content()
    }
}

@Composable
fun SummaryContent(
    title: String,
    transactions: List<Transaction>,
    onDeleteTransaction: (Transaction) -> Unit
) {
    Text("$title: ${transactions.sumOf { it.amount.toInt() }}", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    transactions.forEach { transaction ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(transaction.category, fontSize = 14.sp)
            Text(transaction.amount.toString(), fontSize = 14.sp)
            Button(onClick = { onDeleteTransaction(transaction) }) {
                Text("Delete")
            }
        }
    }
}

@Composable
fun SummaryContent(
    title: String,
    incomeTransactions: List<Transaction>,
    totalIncome: Double,
    onDeleteTransaction: (Transaction) -> Unit
) {
    Text("$title: ${totalIncome.toInt()}", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    incomeTransactions.forEach { transaction ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(transaction.category, fontSize = 14.sp)
            Text(transaction.amount.toString(), fontSize = 14.sp)
            Button(onClick = { onDeleteTransaction(transaction) }) {
                Text("Delete")
            }
        }
    }
}

@Composable
fun DividerLine() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color = Color.LightGray)
    )
}

fun isToday(timestamp: Long): Boolean {
    val today = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return today.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            today.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR)
}

fun isThisWeek(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            now.get(Calendar.WEEK_OF_YEAR) == date.get(Calendar.WEEK_OF_YEAR)
}

fun isThisMonth(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            now.get(Calendar.MONTH) == date.get(Calendar.MONTH)
}
