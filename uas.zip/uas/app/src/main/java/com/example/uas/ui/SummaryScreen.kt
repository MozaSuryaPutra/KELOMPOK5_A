package com.example.uas.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas.data.Budget
import com.example.uas.data.Transaction
import com.example.uas.data.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun SummaryScreen(transactions: List<Transaction>, budgets: List<Budget>) {
    Log.d("SummaryScreen", "Displaying budgets: $budgets")

    val dailyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isToday(it.date) }
    val weeklyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isThisWeek(it.date) }
    val monthlyExpenses = transactions.filter { it.type == TransactionType.EXPENSE && isThisMonth(it.date) }

    val dailyIncome = transactions.filter { it.type == TransactionType.INCOME && isToday(it.date) }
        .groupBy { it.category }
        .mapValues { (_, transactions) -> transactions.sumOf { it.amount } }

    val weeklyIncome = transactions.filter { it.type == TransactionType.INCOME && isThisWeek(it.date) }
        .groupBy { it.category }
        .mapValues { (_, transactions) -> transactions.sumOf { it.amount } }

    val monthlyIncome = transactions.filter { it.type == TransactionType.INCOME && isThisMonth(it.date) }
        .groupBy { it.category }
        .mapValues { (_, transactions) -> transactions.sumOf { it.amount } }

    val totalDailyIncome = dailyIncome.values.sum()
    val totalWeeklyIncome = weeklyIncome.values.sum()
    val totalMonthlyIncome = monthlyIncome.values.sum()

    val currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    val monthlyBudget = budgets.filter { it.month == currentMonth && it.year == currentYear }
    val totalMonthlyBudget = monthlyBudget.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScrollableSection("Daily Summary") {
                SummaryContent("Expenses", dailyExpenses)
                SummaryContent("Income", dailyIncome, totalDailyIncome)
            }
        }

        item {
            DividerLine()
        }

        item {
            ScrollableSection("Weekly Summary") {
                SummaryContent("Expenses", weeklyExpenses)
                SummaryContent("Income", weeklyIncome, totalWeeklyIncome)
            }
        }

        item {
            DividerLine()
        }

        item {
            ScrollableSection("Monthly Summary") {
                SummaryContent("Expenses", monthlyExpenses)
                SummaryContent("Income", monthlyIncome, totalMonthlyIncome)

                Spacer(modifier = Modifier.height(16.dp))

                Text("Budgets", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                monthlyBudget.forEach { budget ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(budget.category, fontSize = 14.sp)
                        Text(budget.amount.toString(), fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Display total monthly budget
                Text("Total Monthly Budget", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(totalMonthlyBudget.toString(), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ScrollableSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.background(Color.LightGray).padding(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))
        content()
    }
}

@Composable
fun SummaryContent(title: String, transactions: List<Transaction>) {
    Text("$title: ${transactions.sumOf { it.amount.toInt() }}", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    transactions.forEach { transaction ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(transaction.category, fontSize = 14.sp)
            Text(transaction.amount.toString(), fontSize = 14.sp)
        }
    }
}

@Composable
fun SummaryContent(title: String, incomeMap: Map<String, Double>, totalIncome: Double) {
    Text("$title: ${totalIncome.toInt()}", fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(8.dp))
    incomeMap.forEach { (category, amount) ->
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(category, fontSize = 14.sp)
            Text(amount.toString(), fontSize = 14.sp)
        }
    }
}

@Composable
fun DividerLine() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color = Color.LightGray)
    )
}

fun isToday(timestamp: Long): Boolean {
    val today = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return today.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            today.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR)
}

fun isThisWeek(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            now.get(Calendar.WEEK_OF_YEAR) == date.get(Calendar.WEEK_OF_YEAR)
}

fun isThisMonth(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
            now.get(Calendar.MONTH) == date.get(Calendar.MONTH)
}
