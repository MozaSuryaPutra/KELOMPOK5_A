package com.example.uas

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.uas.data.AppDatabase
import com.example.uas.data.AppRepository
import com.example.uas.ui.MyApp
import com.example.uas.ui.TransactionViewModel
import com.example.uas.ui.TransactionViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Call setContent to set up Compose content
        setContent {
            // Retrieve ViewModel instance using viewModel function
            val viewModel = provideViewModel()

            // Display the content of the MainActivity
            MainActivityContent(viewModel)
        }
    }

    @Composable
    private fun provideViewModel(): TransactionViewModel {
        // Initialize necessary components
        val database = AppDatabase.getDatabase(applicationContext as Application)
        val repository = AppRepository(database.transactionDao(), database.budgetDao())
        val viewModelFactory = TransactionViewModelFactory(repository)

        // Retrieve ViewModel instance using viewModel function
        return viewModel(factory = viewModelFactory)
    }
}

@Composable
fun MainActivityContent(viewModel: TransactionViewModel) {
    // Example of accessing context if needed
    val context = LocalContext.current

    // Your composable content goes here
    MyApp(viewModel)
}
