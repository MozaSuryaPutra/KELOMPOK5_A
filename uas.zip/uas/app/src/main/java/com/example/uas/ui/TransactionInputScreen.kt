// ui/TransactionInputScreen.kt
package com.example.uas.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.uas.data.Transaction
import com.example.uas.data.TransactionType
import kotlinx.coroutines.launch

@Composable
fun TransactionInputScreen(onSave: (Transaction) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Amount") }
        )
        TextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") }
        )
        Row {
            RadioButton(
                selected = type == TransactionType.INCOME,
                onClick = { type = TransactionType.INCOME }
            )
            Text("Income")
            RadioButton(
                selected = type == TransactionType.EXPENSE,
                onClick = { type = TransactionType.EXPENSE }
            )
            Text("Expense")
        }
        Button(onClick = {
            scope.launch {
                val transaction = Transaction(
                    amount = amount.toDoubleOrNull() ?: 0.0,
                    category = category,
                    type = type,
                    date = System.currentTimeMillis()
                )
                onSave(transaction)
                Toast.makeText(context, "Transaction Saved", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text("Save Transaction")
        }
    }
}
