// data/Transaction.kt
package com.example.uas.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val amount: Double,
    val category: String,
    val type: TransactionType,
    val date: Long
)

enum class TransactionType {
    INCOME, EXPENSE
}
