// MyApp.kt
package com.example.uas.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.uas.data.Budget
import com.example.uas.data.Transaction

@Composable
fun MyApp(viewModel: TransactionViewModel) {
    var transactions by remember { mutableStateOf(emptyList<Transaction>()) }
    var budgets by remember { mutableStateOf(emptyList<Budget>()) }

    LaunchedEffect(viewModel) {
        viewModel.allTransactions.collect { transactions = it }
        viewModel.allBudgets.collect { budgets = it }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        TransactionInputScreen(onSave = { transaction ->
            viewModel.insertTransaction(transaction)
        })

        SummaryScreen(
            transactions = transactions,
            onDeleteTransaction = { transaction ->
                viewModel.deleteTransaction(transaction)
            }
        )
    }
}
